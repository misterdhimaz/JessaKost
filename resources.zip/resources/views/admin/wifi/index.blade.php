<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-jessa-maroon/10 rounded-xl flex items-center justify-center text-jessa-maroon">
                <i class="fas fa-wifi"></i>
            </div>
            <div>
                <h2 class="font-extrabold text-xl text-gray-900 leading-tight">Manajemen WiFi</h2>
                <p class="text-sm text-gray-400 font-medium">Kelola jaringan WiFi untuk penghuni kost</p>
            </div>
        </div>
    </x-slot>

    <div class="space-y-6" x-data="{ showModal: false, showBillModal: false, editMode: false, modalData: { id: null, name: '', ssid: '', password: '' } }">
        <div class="flex justify-end gap-3">
            <button @click="showBillModal = true" class="bg-gray-800 text-white px-5 py-2.5 rounded-xl font-bold shadow-sm hover:bg-gray-900 transition-colors flex items-center gap-2">
                <i class="fas fa-file-invoice-dollar"></i> Tagih WiFi
            </button>
            <button @click="showModal = true; editMode = false; modalData = { id: null, name: '', ssid: '', password: '' }" class="bg-jessa-maroon text-white px-5 py-2.5 rounded-xl font-bold shadow-sm hover:bg-jessa-maroonDark transition-colors flex items-center gap-2">
                <i class="fas fa-plus"></i> Tambah WiFi
            </button>
        </div>

        <div class="bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden">
            <div class="p-6 border-b border-gray-100 bg-gray-50/50">
                <h3 class="font-extrabold text-gray-900 text-lg">Daftar Jaringan WiFi</h3>
            </div>

            <div class="p-6 space-y-4">
                @forelse($wifiNetworks as $wifi)
                <div class="border border-gray-100 rounded-2xl p-5 hover:border-jessa-maroon/30 hover:bg-jessa-cream/20 transition-all flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
                    <div>
                        <h4 class="font-extrabold text-gray-900 text-lg flex items-center gap-2">
                            <i class="fas fa-wifi text-jessa-maroon"></i> {{ $wifi->name }}
                        </h4>
                        <div class="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div class="bg-gray-50 rounded-xl p-3 border border-gray-100">
                                <p class="text-[10px] text-gray-400 font-bold uppercase tracking-wider mb-1">SSID</p>
                                <p class="font-bold text-gray-800">{{ $wifi->ssid }}</p>
                            </div>
                            <div class="bg-gray-50 rounded-xl p-3 border border-gray-100">
                                <p class="text-[10px] text-gray-400 font-bold uppercase tracking-wider mb-1">Password</p>
                                <p class="font-mono text-gray-600">{{ $wifi->password }}</p>
                            </div>
                        </div>
                    </div>

                    <div class="flex gap-2 w-full md:w-auto justify-end mt-4 md:mt-0 pt-4 md:pt-0 border-t md:border-t-0 border-gray-50">
                        <button @click="showModal = true; editMode = true; modalData = { id: '{{ $wifi->id }}', name: '{{ $wifi->name }}', ssid: '{{ $wifi->ssid }}', password: '{{ $wifi->password }}' }" class="p-2 text-blue-600 hover:bg-blue-50 rounded-xl transition-colors" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <form action="{{ route('admin.wifi.destroy', $wifi) }}" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus jaringan WiFi ini?');" class="inline-block">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="p-2 text-red-600 hover:bg-red-50 rounded-xl transition-colors" title="Hapus">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </form>
                    </div>
                </div>
                @empty
                <div class="text-center py-10">
                    <div class="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center text-3xl text-gray-400 mx-auto mb-3">
                        <i class="fas fa-network-wired"></i>
                    </div>
                    <h4 class="font-extrabold text-gray-900 text-lg mb-1">Belum Ada WiFi</h4>
                    <p class="text-gray-500 font-medium text-sm">Tambahkan jaringan WiFi pertama Anda untuk penghuni kost.</p>
                </div>
                @endforelse
            </div>
        </div>

        <!-- Daftar Tagihan WiFi -->
        <div class="bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden mt-8">
            <div class="px-8 py-6 border-b border-gray-100 bg-gray-50/50 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 bg-jessa-maroon/10 text-jessa-maroon rounded-xl flex items-center justify-center">
                        <i class="fas fa-file-invoice-dollar text-lg"></i>
                    </div>
                    <div>
                        <h3 class="font-extrabold text-gray-900 text-lg">Daftar Tagihan WiFi</h3>
                        <p class="text-sm text-gray-500 font-medium">Riwayat tagihan internet penghuni</p>
                    </div>
                </div>

                <!-- Filter & Search Form -->
                <form method="GET" action="{{ route('admin.wifi.index') }}" class="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
                    <select name="status" class="w-full sm:w-auto bg-white border border-gray-200 text-gray-700 text-sm rounded-xl focus:ring-jessa-maroon focus:border-jessa-maroon py-2.5 px-4 font-bold" onchange="this.form.submit()">
                        <option value="">Semua Status</option>
                        <option value="paid" {{ request('status') == 'paid' ? 'selected' : '' }}>Lunas</option>
                        <option value="unpaid" {{ request('status') == 'unpaid' ? 'selected' : '' }}>Belum Lunas</option>
                    </select>

                    <div class="relative w-full sm:w-64">
                        <input type="text" name="search" value="{{ request('search') }}" placeholder="Cari penghuni..." class="w-full bg-white border border-gray-200 text-gray-700 text-sm rounded-xl focus:ring-jessa-maroon focus:border-jessa-maroon pl-10 pr-4 py-2.5 font-medium">
                        <i class="fas fa-search absolute left-3.5 top-3 text-gray-400"></i>
                    </div>

                    <button type="submit" class="hidden"></button>
                </form>
            </div>

            <div class="p-8">
                <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    @forelse($internetBills as $bill)
                    <div class="border border-gray-100 rounded-2xl p-5 hover:shadow-md transition-all group bg-white relative overflow-hidden">
                        @if($bill->status == 'paid')
                        <div class="absolute top-0 right-0 w-16 h-16 overflow-hidden rounded-tr-2xl">
                            <div class="bg-green-500 text-white text-[10px] font-black uppercase tracking-wider py-1 w-24 text-center absolute top-3 -right-6 rotate-45 shadow-sm">
                                LUNAS
                            </div>
                        </div>
                        @endif

                        <div class="flex items-center gap-4 mb-4 relative z-10">
                            <div class="w-12 h-12 bg-jessa-maroon/10 text-jessa-maroon rounded-xl flex items-center justify-center text-xl font-bold">
                                {{ $bill->lease->room->room_number ?? '?' }}
                            </div>
                            <div>
                                <h4 class="font-bold text-gray-900">{{ $bill->lease->user->name ?? 'Penghuni' }}</h4>
                                <p class="text-xs text-gray-500 font-medium">Periode: {{ \Carbon\Carbon::parse($bill->billing_period)->translatedFormat('F Y') }}</p>
                            </div>
                        </div>

                        <div class="flex justify-between items-center mt-4 pt-4 border-t border-gray-100 relative z-10">
                            <div>
                                <p class="text-xs text-gray-400 font-bold uppercase tracking-wider mb-0.5">Total Tagihan</p>
                                <p class="font-black text-jessa-maroon text-lg">Rp {{ number_format($bill->amount, 0, ',', '.') }}</p>
                            </div>
                            <div class="text-right">
                                @if($bill->status == 'unpaid')
                                <span class="px-3 py-1 bg-red-50 text-red-600 rounded-lg text-xs font-bold border border-red-100 inline-block mb-2">
                                    <i class="fas fa-clock mr-1"></i> Belum Bayar
                                </span>
                                @endif
                                <div class="flex gap-2 justify-end">
                                    <a href="{{ route('admin.electricity.edit', $bill->id) }}" class="inline-flex justify-center items-center bg-blue-50 hover:bg-blue-100 text-blue-600 w-8 h-8 rounded-lg text-xs font-bold transition-colors border border-blue-200" title="Edit Tagihan">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="{{ route('admin.electricity.destroy', $bill->id) }}" method="POST" class="inline-block" onsubmit="return confirm('Hapus tagihan WiFi ini?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="inline-flex justify-center items-center bg-red-50 hover:bg-red-100 text-red-600 w-8 h-8 rounded-lg text-xs font-bold transition-colors border border-red-200" title="Hapus">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    @empty
                    <div class="col-span-full py-10 text-center">
                        <div class="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center text-3xl text-gray-400 mx-auto mb-3">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <h4 class="font-extrabold text-gray-900 text-lg mb-1">Belum Ada Tagihan</h4>
                        <p class="text-gray-500 font-medium text-sm">Tidak ada tagihan WiFi yang sesuai.</p>
                    </div>
                    @endforelse
                </div>
            </div>
        </div>


        <!-- Modal Form -->
        <div x-show="showModal" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
            <div class="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:p-0">
                <div x-show="showModal" x-transition:enter="ease-out duration-300" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100" x-transition:leave="ease-in duration-200" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0" class="fixed inset-0 transition-opacity bg-gray-900/50 backdrop-blur-sm" @click="showModal = false" aria-hidden="true"></div>

                <div x-show="showModal" x-transition:enter="ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95" x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100" x-transition:leave="ease-in duration-200" x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100" x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95" class="relative inline-block w-full max-w-md p-8 overflow-hidden text-left align-bottom transition-all transform bg-white shadow-xl rounded-[2rem] sm:my-8 sm:align-middle">

                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-xl font-extrabold text-gray-900" x-text="editMode ? 'Edit WiFi' : 'Tambah WiFi Baru'"></h3>
                        <button type="button" @click="showModal = false" class="text-gray-400 hover:text-gray-500 transition-colors">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>

                    <form :action="editMode ? '{{ url('admin/wifi') }}/' + modalData.id : '{{ route('admin.wifi.store') }}'" method="POST" class="space-y-5">
                        @csrf
                        <template x-if="editMode">
                            <input type="hidden" name="_method" value="PUT">
                        </template>

                        <div>
                            <x-input-label for="name" value="Nama Jaringan (Label)" />
                            <x-text-input id="name" name="name" type="text" class="mt-1 block w-full" x-model="modalData.name" required placeholder="Contoh: WiFi Lantai 1" />
                            <x-input-error :messages="$errors->get('name')" class="mt-2" />
                        </div>

                        <div>
                            <x-input-label for="ssid" value="SSID (Nama WiFi)" />
                            <x-text-input id="ssid" name="ssid" type="text" class="mt-1 block w-full" x-model="modalData.ssid" required placeholder="Contoh: JessaKost_1" />
                            <x-input-error :messages="$errors->get('ssid')" class="mt-2" />
                        </div>

                        <div>
                            <x-input-label for="password" value="Password WiFi" />
                            <x-text-input id="password" name="password" type="text" class="mt-1 block w-full" x-model="modalData.password" required placeholder="Contoh: jessa2024" />
                            <x-input-error :messages="$errors->get('password')" class="mt-2" />
                        </div>

                        <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-gray-100">
                            <button type="button" @click="showModal = false" class="px-5 py-2.5 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-xl font-bold transition-colors">Batal</button>
                            <button type="submit" class="px-5 py-2.5 text-white bg-jessa-maroon hover:bg-jessa-maroonDark rounded-xl font-bold shadow-sm transition-colors" x-text="editMode ? 'Simpan Perubahan' : 'Tambah WiFi'"></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        {{-- Modal Tagih WiFi --}}
        <div x-show="showBillModal" style="display: none;" class="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/60 backdrop-blur-sm p-4" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100" x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0">
            <div class="bg-white rounded-[2rem] w-full max-w-md shadow-2xl overflow-hidden" @click.away="showBillModal = false" x-transition:enter="transition ease-out duration-300 delay-100" x-transition:enter-start="opacity-0 scale-95 translate-y-4" x-transition:enter-end="opacity-100 scale-100 translate-y-0">
                <div class="px-6 py-5 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                    <h3 class="text-xl font-extrabold text-gray-900"><i class="fas fa-file-invoice-dollar text-jessa-maroon mr-2"></i> Tagih WiFi ke Penghuni</h3>
                    <button @click="showBillModal = false" class="text-gray-400 hover:text-red-500 transition-colors w-8 h-8 flex items-center justify-center rounded-full hover:bg-red-50">
                        <i class="fas fa-times text-lg"></i>
                    </button>
                </div>
                <div class="p-6">
                    <form action="{{ route('admin.wifi.bill') }}" method="POST" class="space-y-4">
                        @csrf
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">Penghuni Aktif <span class="text-red-500">*</span></label>
                            <select name="tenant_id" required class="w-full rounded-xl border-gray-200 bg-gray-50 px-4 py-3 text-gray-700 focus:ring-2 focus:ring-jessa-maroon/20 focus:border-jessa-maroon">
                                <option value="">-- Pilih Penghuni --</option>
                                @foreach($tenants ?? [] as $tenant)
                                    <option value="{{ $tenant->id }}">{{ $tenant->name }} (Kamar {{ $tenant->leases->first()->room->room_number ?? '?' }})</option>
                                @endforeach
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">Periode Tagihan <span class="text-red-500">*</span></label>
                            <input type="month" name="billing_period" required value="{{ date('Y-m') }}" class="w-full rounded-xl border-gray-200 bg-gray-50 px-4 py-3 text-gray-700 focus:ring-2 focus:ring-jessa-maroon/20 focus:border-jessa-maroon">
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">Nominal Tagihan (Rp) <span class="text-red-500">*</span></label>
                            <input type="number" name="amount" required min="0" class="w-full rounded-xl border-gray-200 bg-gray-50 px-4 py-3 text-gray-700 focus:ring-2 focus:ring-jessa-maroon/20 focus:border-jessa-maroon" placeholder="Contoh: 150000">
                        </div>
                        <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-gray-100">
                            <button type="button" @click="showBillModal = false" class="px-5 py-2.5 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-xl font-bold transition-colors">Batal</button>
                            <button type="submit" class="px-5 py-2.5 text-white bg-jessa-maroon hover:bg-jessa-maroonDark rounded-xl font-bold shadow-sm transition-colors">Kirim Tagihan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>


